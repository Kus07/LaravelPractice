@include('templates.header')

<x-navbar />

<h1>This is the contact page</h1>

@include('templates.footer')
