@include('templates.header')

<x-navbar />

<h1>This is the register page</h1>

@include('templates.footer')
