    @include('templates.header')

    <x-navbar />

    <h1>This is the login page</h1>

    @include('templates.footer')
