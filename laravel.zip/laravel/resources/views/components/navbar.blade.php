<a href="/">All Products</a> |
    <a href="/login">Login</a> |
    <a href="/register">Register</a>
    <a href="/contact">Contact</a>
    <br>
    <br>